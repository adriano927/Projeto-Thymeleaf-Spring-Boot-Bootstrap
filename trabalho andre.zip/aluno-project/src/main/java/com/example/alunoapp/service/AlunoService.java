package com.example.alunoapp.service;

import com.example.alunoapp.model.Aluno;
import com.example.alunoapp.repository.AlunoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AlunoService {
    private final AlunoRepository repo;

    public AlunoService(AlunoRepository repo) {
        this.repo = repo;
    }

    public List<Aluno> findAll() { return repo.findAll(); }

    public Optional<Aluno> findById(Long id) { return repo.findById(id); }

    public Aluno save(Aluno a) { return repo.save(a); }

    public void deleteById(Long id) { repo.deleteById(id); }

    public boolean matriculaExistente(String matricula) {
        return repo.existsByMatricula(matricula);
    }
}

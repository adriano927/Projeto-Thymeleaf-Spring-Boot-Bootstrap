package com.example.alunoapp.controller;

import com.example.alunoapp.model.Aluno;
import com.example.alunoapp.service.AlunoService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/alunos")
public class AlunoController {

    private final AlunoService service;

    public AlunoController(AlunoService service) {
        this.service = service;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("alunos", service.findAll());
        return "alunos/list";
    }

    @GetMapping("/novo")
    public String createForm(Model model) {
        model.addAttribute("aluno", new Aluno());
        return "alunos/form";
    }

    @PostMapping("/salvar")
    public String save(@Valid @ModelAttribute("aluno") Aluno aluno,
                       BindingResult br,
                       RedirectAttributes ra) {
        if (br.hasErrors()) {
            return "alunos/form";
        }
        // checar matrícula única quando for novo (id == null)
        if (aluno.getId() == null && service.matriculaExistente(aluno.getMatricula())) {
            br.rejectValue("matricula", "matricula.exists", "Matrícula já cadastrada");
            return "alunos/form";
        }
        service.save(aluno);
        ra.addFlashAttribute("success", "Aluno salvo com sucesso.");
        return "redirect:/alunos";
    }

    @GetMapping("/editar/{id}")
    public String edit(@PathVariable Long id, Model model, RedirectAttributes ra) {
        return service.findById(id)
                .map(a -> {
                    model.addAttribute("aluno", a);
                    return "alunos/form";
                })
                .orElseGet(() -> {
                    ra.addFlashAttribute("error", "Aluno não encontrado.");
                    return "redirect:/alunos";
                });
    }

    @GetMapping("/excluir/{id}")
    public String delete(@PathVariable Long id, RedirectAttributes ra) {
        service.deleteById(id);
        ra.addFlashAttribute("success", "Aluno excluído.");
        return "redirect:/alunos";
    }
}

Projeto: Cadastro de Alunos - Spring Boot + Thymeleaf + Bootstrap
Descrição: Projeto exemplo para cadastrar, listar, editar e excluir alunos.
Como rodar:
 1. Importar no IntelliJ/VSCode como projeto Maven.
 2. Executar: mvn spring-boot:run
 3. Acessar: http://localhost:8080/alunos
 H2 Console: http://localhost:8080/h2-console (jdbc:h2:mem:db)
